const buttons = document.querySelectorAll(".select-rating-button");

const activeState = function () {
    document.querySelector(".selected-rating")?.classList.remove("selected-rating");
    this.classList.add("selected-rating");
};

buttons.forEach(button => {
    button.addEventListener("click", activeState);
});

const SubmitButton = document.querySelector(".submit-button");
const firstContainer = document.querySelector(".card-container");
const secondContainer = document.querySelector(".rating-container");
const spanRating = document.querySelector(".selected-rate");

const handleSubmit = () => {
    const selectedRating = document.querySelector(".selected-rating");
   
    if(selectedRating !== null){
        firstContainer.style.display = "none";
        secondContainer.style.display = "block";
        spanRating.textContent = selectedRating.textContent;
    }
}
